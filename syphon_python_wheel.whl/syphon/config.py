SYPHON_FRAMEWORK_PATH = '/Users/bentodman/Projects/ArtnetViz/frameworks/Syphon.framework'
